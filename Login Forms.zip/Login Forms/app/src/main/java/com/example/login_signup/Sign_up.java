package com.example.login_signup;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class Sign_up extends AppCompatActivity {

    Button Signup;
    EditText Fname;
    EditText Lname;
    EditText Email;
    EditText Phone;
    EditText Password;
    String tempEmail = "abc@email.com";
    String tempPassword = "Abc123";
    String PhonePattern= "[0-9]{12}";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        Fname = findViewById(R.id.Signup_Fname);
        Lname = findViewById(R.id.Signup_Lname);
        Email = findViewById(R.id.Signup_Email);
        Phone = findViewById(R.id.Signup_phone);
        Password = findViewById(R.id.Signup_password);
        Signup = findViewById(R.id.Signup_btnsignup);

        final Login obj = new Login();

        Signup.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(TextUtils.isEmpty(Fname.getText().toString())){
                    Fname.setError("Fill First name.");
                }else{
                    if(Fname.getText().toString().length()<3){
                        Fname.setError("First name letter(s) should be more then 3.");
                    }else{
                        if(TextUtils.isEmpty(Lname.getText().toString())){
                            Lname.setError("Fill Last name.");
                        }else{
                            if(Lname.getText().toString().length()<3){
                                Fname.setError("Last name letter(s) should be more then 3.");
                            }else{
                                if(TextUtils.isEmpty(Email.getText().toString())){
                                    Email.setError("Fill email.");
                                }else{
                                    if(TextUtils.isEmpty(Phone.getText().toString())){
                                        Phone.setError("Fill phone.");
                                    }else {
                                        if(Phone.getText().toString().matches(PhonePattern)){
                                            Phone.setError("Invalid phone number.");
                                        }else{
                                            if(TextUtils.isEmpty(Password.getText().toString())){
                                                Password.setError("Fill password.");
                                            }else{
                                                if(!Patterns.EMAIL_ADDRESS.matcher(Email.getText().toString()).matches()){
                                                    Toast t = Toast.makeText(Sign_up.this , "Invalid Email" , Toast.LENGTH_SHORT);
                                                    t.show();
                                                }else{
                                                    tempEmail = Email.getText().toString();
                                                    tempPassword = Password.getText().toString();
                                                    Toast t = Toast.makeText(Sign_up.this , "Sign ups Successfully" , Toast.LENGTH_SHORT);
                                                    t.show();
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        });
    }
    public String getEmail(){
        return tempEmail;
    }
    public String getPassword(){
        return tempPassword;
    }
}

