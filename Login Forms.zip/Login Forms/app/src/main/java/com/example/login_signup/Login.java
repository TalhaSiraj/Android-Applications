package com.example.login_signup;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {

    Button Login;
    EditText Email;
    EditText Password;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        final Sign_up OBJ = new Sign_up();
        Email = findViewById(R.id.login_userID);
        Password = findViewById(R.id.login_userpassword);
        Login = findViewById(R.id.login_btnlogin);
        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(TextUtils.isEmpty(Email.getText().toString())){
                    Email.setError("Please Enter Email");
                }else{
                    if(TextUtils.isEmpty(Password.getText().toString())){
                        Password.setError("Please Enter Password");
                    }else{
                        if(!Patterns.EMAIL_ADDRESS.matcher(Email.getText().toString()).matches()){
                            Toast t = Toast.makeText(Login.this , "Your Email Is Invalid" , Toast.LENGTH_SHORT);
                            t.show();
                        }else{
                            if(Email.getText().toString().equals(OBJ.getEmail()) && Password.getText().toString().equals(OBJ.getPassword())){
                                Toast t = Toast.makeText(Login.this , "You Login Was Successful" , Toast.LENGTH_SHORT);
                                t.show();
                            }else{
                                Toast t = Toast.makeText(Login.this , "Your Email Or Password Is Invalid" , Toast.LENGTH_SHORT);
                                t.show();
                            }
                        }
                    }
                }
            }
        });
    }
}
