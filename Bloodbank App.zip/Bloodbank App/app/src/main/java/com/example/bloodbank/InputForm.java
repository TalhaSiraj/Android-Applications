package com.example.bloodbank;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import static android.widget.Toast.LENGTH_LONG;

public class InputForm extends AppCompatActivity {

    EditText Name,fatherName,CNIC,BloodGrp,Contact,Gender,HSname,Attendent_Name,Attendent_Contact,address,Age;
    Button Submitbtn;
    DatabaseReference Reference,AdminReference;
    BloodDonation bloodobjectDonation;
    BloodNeed bloodNeed;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inputform);
        Intent intent = getIntent();
        String Needtype = intent.getStringExtra(LoginForm.UserNameKey);
        String AuthKey =  intent.getStringExtra(LoginForm.AuthKey);
        LinearLayout one = (LinearLayout) findViewById(R.id.patientform);
        LinearLayout two = (LinearLayout) findViewById(R.id.donateformlayout);


        if(Needtype.contains("Donate")){
            two.setVisibility(View.VISIBLE);
            bloodobjectDonation = new BloodDonation();
            Name = findViewById(R.id.d_name);
            fatherName = findViewById(R.id.d_father_name);
            Age = findViewById(R.id.d_age);
            Contact = findViewById(R.id.d_Cont);
            address = findViewById(R.id.d_address);

            Submitbtn = findViewById(R.id.donateformbutton);


        }else{
            bloodNeed = new BloodNeed();
            one.setVisibility(View.VISIBLE);
            Name = findViewById(R.id.Pname);
            CNIC = findViewById(R.id.pcnic);
            BloodGrp = findViewById(R.id.p_bloodgrp);
            Contact = findViewById(R.id.p_Cont);
            Gender = findViewById(R.id.p_Gend);
            HSname = findViewById(R.id.p_host_name);
            Attendent_Name = findViewById(R.id.Attent_Name_);
            Attendent_Contact = findViewById(R.id.Attent_Contact_);

            Submitbtn = findViewById(R.id.needformbutton);
        }

        Submitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Needtype.contains("Donate")){
                    if (TextUtils.isEmpty(Name.getText().toString())) {
                        Name.setError("Fill First name.");
                    }else{
                        if (TextUtils.isEmpty(fatherName.getText().toString())) {
                            fatherName.setError("Fill father name.");
                        }else{
                            if (TextUtils.isEmpty(Age.getText().toString())) {
                                Age.setError("Fill Age.");
                            }else{
                                if (TextUtils.isEmpty(Contact.getText().toString())) {
                                    Contact.setError("Fill Contact.");
                                }else{
                                    if (TextUtils.isEmpty(address.getText().toString())) {
                                        address.setError("Fill address.");
                                    }else{
                                        bloodobjectDonation.setname(Name.getText().toString());
                                        bloodobjectDonation.setFathername(fatherName.getText().toString());
                                        bloodobjectDonation.setage(Age.getText().toString());
                                        bloodobjectDonation.setaddress(address.getText().toString());
                                        bloodobjectDonation.setrequeststatus("False");
                                        bloodobjectDonation.setcontact(Contact.getText().toString());
                                        try{
                                            Reference = FirebaseDatabase.getInstance().getReference().child(AuthKey);
                                            Reference.child(Needtype).setValue(bloodobjectDonation);
                                            AdminReference = FirebaseDatabase.getInstance().getReference().child("Admin");
                                            AdminReference.child(AuthKey).setValue(Needtype);;
                                            Toast t = Toast.makeText(InputForm.this,"Donate Form submit",LENGTH_LONG);
                                            t.show();
                                            Intent intent = new Intent(InputForm.this, HomePage.class);
                                            startActivity(intent);
                                        }catch (Exception e){
                                        }

                                    }
                                }
                            }
                        }
                    }
                }else{
                    if (TextUtils.isEmpty(Name.getText().toString())) {
                        Name.setError("Fill First name.");
                    }else{
                        if (TextUtils.isEmpty(CNIC.getText().toString())) {
                            CNIC.setError("Fill CNIC.");
                        }else{
                            if (TextUtils.isEmpty(BloodGrp.getText().toString())) {
                                BloodGrp.setError("Fill Blood Group.");
                            }else{
                                if (TextUtils.isEmpty(Contact.getText().toString())) {
                                    Contact.setError("Fill Contact.");
                                }else{
                                    if (TextUtils.isEmpty(Gender.getText().toString())) {
                                        Gender.setError("Fill Gender.");
                                    }else{
                                        if (TextUtils.isEmpty(HSname.getText().toString())) {
                                            HSname.setError("Fill Hospital name.");
                                        }else{
                                            if (TextUtils.isEmpty(Attendent_Name.getText().toString())) {
                                                Attendent_Name.setError("Fill Attendent name.");
                                            }else{
                                                if (TextUtils.isEmpty(Attendent_Contact.getText().toString())) {
                                                    Attendent_Contact.setError("Fill Attendent Contact.");
                                                }else{
                                                    bloodNeed.setname(Name.getText().toString());
                                                    bloodNeed.setCnic(CNIC.getText().toString());
                                                    bloodNeed.setbloodgrp(BloodGrp.getText().toString());
                                                    bloodNeed.setcontact(Contact.getText().toString());
                                                    bloodNeed.setgender(Gender.getText().toString());
                                                    bloodNeed.sethospitalname(HSname.getText().toString());
                                                    bloodNeed.setattendentname(Attendent_Name.getText().toString());
                                                    bloodNeed.setattendentcontact(Attendent_Contact.getText().toString());
                                                    bloodNeed.setrequeststatus("false");
                                                    try{
                                                        Reference = FirebaseDatabase.getInstance().getReference().child(AuthKey);
                                                        Reference.child(Needtype).setValue(bloodNeed);
                                                        AdminReference = FirebaseDatabase.getInstance().getReference().child("Admin");
                                                        AdminReference.child(AuthKey).setValue(Needtype);
                                                        Toast t = Toast.makeText(InputForm.this,"Need Form submited",LENGTH_LONG);
                                                        t.show();
                                                        Intent intent = new Intent(InputForm.this, HomePage.class);
                                                        startActivity(intent);
                                                    }catch(Exception e){}
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        });
    }
}
