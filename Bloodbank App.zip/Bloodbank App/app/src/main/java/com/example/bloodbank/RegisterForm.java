package com.example.bloodbank;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterForm extends AppCompatActivity {

    Button Signup;
    EditText Fname,password,Confirmpass;
    EditText Lname;
    EditText Email;
    EditText Phone;
    EditText Gender;
    String PhonePattern= "[0-9]{12}";
    String Usertype ="";
    FirebaseAuth fAuth;
    DatabaseReference Reference;
    UserInformation cmu;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registerform);
        cmu = new UserInformation();
        Intent intent =getIntent();
        fAuth = FirebaseAuth.getInstance();
        Usertype = intent.getStringExtra(HomePage.UserNameKey);

        Fname = findViewById(R.id.Fname);
        Lname = findViewById(R.id.Lname);
        Email = findViewById(R.id.Signup_Email);
        Phone = findViewById(R.id.phone);
        Gender = findViewById(R.id.Gender);
        Signup = findViewById(R.id.Signup_btnsignup);
        password = findViewById(R.id.password);
        Confirmpass = findViewById(R.id.Confirmpassword);


        Signup.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(Fname.getText().toString())) {
                    Fname.setError("Fill First name.");
                } else {
                    if (Fname.getText().toString().length() < 3) {
                        Fname.setError("First name letter(s) should be more then 3.");
                    } else {
                        if (TextUtils.isEmpty(Lname.getText().toString())) {
                            Lname.setError("Fill Last name.");
                        } else {
                            if (Lname.getText().toString().length() < 3) {
                                Lname.setError("Last name letter(s) should be more then 3.");
                            } else {
                                if (TextUtils.isEmpty(Email.getText().toString())) {
                                    Email.setError("Fill Email.");
                                } else {
                                    if (TextUtils.isEmpty(Phone.getText().toString())) {
                                        Phone.setError("Fill phone.");
                                    } else {
                                        if (Phone.getText().toString().matches(PhonePattern)) {
                                            Phone.setError("Invalid phone number.");
                                        } else {
                                            if (TextUtils.isEmpty(Gender.getText().toString())) {
                                                Gender.setError("Fill gender.");
                                            } else {
                                                if (!Patterns.EMAIL_ADDRESS.matcher(Email.getText().toString()).matches() || Email.getText().toString().length() < 3) {
                                                    Email.setError("Invalid Email.");
                                                } else {
                                                    if(TextUtils.isEmpty(password.getText().toString())){
                                                        password.setError("Fill password.");
                                                    }else{
                                                        if(TextUtils.isEmpty(Confirmpass.getText().toString())){
                                                            Confirmpass.setError("Fill Confirm password.");
                                                        }else{
                                                            if(!Confirmpass.getText().toString().contains(password.getText().toString())){
                                                                Confirmpass.setError("Password not matched.");
                                                            }else{
                                                                    fAuth.createUserWithEmailAndPassword(Email.getText().toString().trim(),password.getText().toString().trim()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                                                        @Override
                                                                        public void onComplete(@NonNull Task<AuthResult> task) {
                                                                            if(task.isSuccessful()){
                                                                                cmu.setFname(Fname.getText().toString().trim());
                                                                                cmu.setLname(Lname.getText().toString().trim());
                                                                                cmu.setGender(Gender.getText().toString().trim());
                                                                                cmu.setContact(Phone.getText().toString().trim());
                                                                                cmu.setUsertype(Usertype);
                                                                                Toast t = Toast.makeText(RegisterForm.this, "SignUp Successfully ", Toast.LENGTH_SHORT);
                                                                                t.show();
                                                                                Reference = FirebaseDatabase.getInstance().getReference().child(fAuth.getUid());
                                                                                Reference.child(fAuth.getUid()).setValue(cmu);
                                                                                fAuth.signOut();
                                                                                Intent intent1 = new Intent(RegisterForm.this, HomePage.class);
                                                                                startActivity(intent1);
                                                                            }else{
                                                                                Toast t = Toast.makeText(RegisterForm.this, "Error!  "+task.getException(), Toast.LENGTH_SHORT);
                                                                                t.show();
                                                                            }
                                                                        }
                                                                    });
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        });
    }
}
