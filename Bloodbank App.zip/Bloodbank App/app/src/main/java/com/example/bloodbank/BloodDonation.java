package com.example.bloodbank;

public class BloodDonation {

    private String Creatorname,Fathername ,age ,contact, address,requeststatus;
    public BloodDonation(){}
    public void setname(String name){this.Creatorname = name;}
    public void setFathername(String Fathername){this.Fathername= Fathername;}
    public void setage(String age){this.age= age;}
    public void setaddress(String address){this.address= address;}
    public void setrequeststatus(String requeststatus){this.requeststatus= requeststatus;}
    public void setcontact(String contact){this.contact= contact;}
    public String getname(){return this.Creatorname;}
    public String getFathername(){return this.Fathername ;}
    public String getage(){return this.age;}
    public String getaddress(){return this.address;}
    public String getrequeststatus(){return this.requeststatus;}
    public String getcontact(){return this.contact;}
}
