package com.example.bloodbank;

public class BloodNeed {

    private String name ,cnic , bloodgrouptype,contact, gender,hospitalname,attendentname,attendentcontact,requeststatus;
    BloodNeed(){}
    public void setname(String name){this.name = name;}
    public void setCnic(String cnic){this.cnic= cnic;}
    public void setbloodgrp(String bloodgrp){this.bloodgrouptype = bloodgrp;}
    public void setcontact(String contact){this.contact= contact;}
    public void setgender(String gender){this.gender= gender;}
    public void sethospitalname(String hospitalname){this.hospitalname= hospitalname;}
    public void setattendentname(String attendentname){this.attendentname= attendentname;}
    public void setattendentcontact(String attendentcontact){this.attendentcontact= attendentcontact;}
    public void setrequeststatus(String requeststatus){this.requeststatus= requeststatus;}
    public String getname(){return this.name;}
    public String getcnic(){return this.cnic ;}
    public String getbloodgrp(){return this.bloodgrouptype;}
    public String getcontact(){return this.contact;}
    public String getgender(){return this.gender;}
    public String gethospitalname(){return this.hospitalname;}
    public String getattendentname(){return this.attendentname;}
    public String getattendentcontact(){return this.attendentcontact;}
    public String getrequeststatus(){return this.requeststatus;}
}
