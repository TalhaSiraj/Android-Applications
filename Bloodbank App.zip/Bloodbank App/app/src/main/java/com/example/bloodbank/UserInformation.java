package com.example.bloodbank;

public class UserInformation {
    private String Fname,Lname,Gender,Usertype,Contact,NeedType;

    public UserInformation(){

    }
    public void setFname(String Fname){this.Fname = Fname;}
    public void setLname(String Lname){this.Lname = Lname;}
    public void setGender(String Gender){this.Gender= Gender;}
    public void setUsertype(String Usertype){this.Usertype= Usertype;}
    public void setContact(String Contact){this.Contact= Contact;}
    public void setNeedType(String NeedType){this.NeedType= NeedType;}

    public String getFname(){return this.Fname;}
    public String getLname(){return this.Lname;}
    public String getGender(){return this.Gender ;}
    public String getUsertype(){return this.Usertype;}
    public String getContact(){return this.Contact;}
    public String getNeedType(){return this.NeedType;}
}
