package com.example.bloodbank;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import static android.widget.Toast.LENGTH_LONG;

public class LoginForm extends AppCompatActivity {

    public static final String UserNameKey="loginuser",AuthKey = "authkey";
    EditText Email;
    EditText password;
    Button login , Userbtn;
    RadioGroup RG;
    RadioButton R_btn;
    FirebaseAuth  fAuth;
    LinearLayout AdminLayout,user,one,adminInnerlayout;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginform);

        one = (LinearLayout) findViewById(R.id.loginlayout);
        user = (LinearLayout) findViewById(R.id.userlayout);
        AdminLayout = (LinearLayout) findViewById(R.id.Adminrootlayout);
        adminInnerlayout = (LinearLayout) findViewById(R.id.AdminLayout);

        Email = findViewById(R.id.login_Email);
        password = findViewById(R.id.login_password);
        login = findViewById(R.id.loginbtn);
        Userbtn = findViewById(R.id.loginbtn2);

        fAuth=FirebaseAuth.getInstance();

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(TextUtils.isEmpty(Email.getText().toString())){
                    Email.setError("Fill email address");
                }else{
                    if(TextUtils.isEmpty(password.getText().toString())){
                        password.setError("Fill email address");
                    }else{
                        fAuth.signInWithEmailAndPassword(Email.getText().toString().trim(),password.getText().toString().trim()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if(task.isComplete()){
                                    DatabaseReference Reference = FirebaseDatabase.getInstance().getReference().child(fAuth.getUid()).child(fAuth.getUid());
                                    Reference.addValueEventListener(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                                            String usertype = snapshot.child("usertype").getValue().toString();
                                            if(usertype.contains("BloodBank")){
                                                one.setVisibility(View.GONE);
                                                AdminLayout.setVisibility(View.VISIBLE);
                                                try{
                                                    DatabaseReference DBReference = FirebaseDatabase.getInstance().getReference().child("Admin");
                                                    DBReference.addValueEventListener(new ValueEventListener() {
                                                        @Override
                                                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                            for (DataSnapshot postSnapshot: snapshot.getChildren()) {
                                                                String DataKey = String.valueOf(postSnapshot.getKey());
                                                                String DataValue = String.valueOf(postSnapshot.getValue());
                                                                try{
                                                                    DatabaseReference DBRefere = FirebaseDatabase.getInstance().getReference().child(DataKey).child(DataValue);
                                                                    DBRefere.addValueEventListener(new ValueEventListener() {
                                                                        @Override
                                                                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                                            String n = snapshot.child("name").getValue().toString();
                                                                            String c = snapshot.child("contact").getValue().toString();
                                                                            String r = snapshot.child("requeststatus").getValue().toString();
                                                                            String blood = DataValue;
                                                                            if(DataValue.contains("Need Blood")){
                                                                                blood = snapshot.child("bloodgrp").getValue().toString();
                                                                                blood =DataValue+" ("+blood+")";
                                                                            }
                                                                            AddLayout(n,c,blood,r);
                                                                        }

                                                                        @Override
                                                                        public void onCancelled(@NonNull DatabaseError error) {

                                                                        }
                                                                    });
                                                                }catch (Throwable e){}
//                                                                AddLayout();

                                                            }
                                                        }

                                                        @Override
                                                        public void onCancelled(@NonNull DatabaseError error) {

                                                        }
                                                    });
                                                }catch (Throwable e){}
                                            }else{
                                                if(usertype.contains("commanuser")){
                                                    one.setVisibility(View.GONE);
                                                    user.setVisibility(View.VISIBLE);
                                                    RG = findViewById(R.id.RG_);
                                                    int radio_id = RG.getCheckedRadioButtonId();
                                                    R_btn = findViewById(radio_id);
                                                    Userbtn.setOnClickListener(new View.OnClickListener() {
                                                    @Override
                                                    public void onClick(View v) {
                                                    try{
                                                        Intent intent = new Intent(LoginForm.this, InputForm.class);
                                                        if(R_btn.getText().toString().contains("Need Blood")){
                                                        intent.putExtra(UserNameKey,"Need Blood");
                                                        intent.putExtra(AuthKey,fAuth.getUid());
                                                        startActivity(intent);
                                                        }else{
                                                            if(R_btn.getText().toString().contains("Donate Blood")){
                                                                intent.putExtra(UserNameKey,"Donate Blood");
                                                                intent.putExtra(AuthKey,fAuth.getUid());
                                                                startActivity(intent);
                                                            }
                                                        }
                                                    }catch (Throwable e){
                                            Toast t = Toast.makeText(LoginForm.this,"Please Select One Option",LENGTH_LONG);
                                            t.show();
                                    }
                                }
                            });
                        }
                                            }
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) {

                                        }
                                    });
                               }else{
                            Toast t = Toast.makeText(LoginForm.this,"Email or Password is not valid",LENGTH_LONG);
                            t.show();
                                }
                            }
                        });
                    }
                }
            }
        });
    }
    public void Check_fun(View v){
        int radio_id = RG.getCheckedRadioButtonId();
        R_btn = findViewById(radio_id);
    }
    public void AddLayout(String Name,String Contact,String RequestType,String reqStatus){
        View userView = getLayoutInflater().inflate(R.layout.activity_loginadmin,null,false);
        TextView userName = userView.findViewById(R.id.userName);
        TextView userContact = userView.findViewById(R.id.userContact);
        TextView userRequest = userView.findViewById(R.id.userRequest);
        TextView RequestStatus = userView.findViewById(R.id.RequestStatus);
        Button requestacceptbtn = userView.findViewById(R.id.acceptbtn);
        Button requestrejectbtn = userView.findViewById(R.id.rejectbtn);

        userName.setText(Name);
        userContact.setText(Contact);
        userRequest.setText(RequestType);
        RequestStatus.setText(reqStatus);

        adminInnerlayout.addView(userView);
        requestacceptbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RequestStatus.setText("Accepted");
            }
        });
        requestrejectbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RequestStatus.setText("Rejected");
            }
        });

    }
}
