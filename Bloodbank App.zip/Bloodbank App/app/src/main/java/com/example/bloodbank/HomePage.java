package com.example.bloodbank;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class HomePage extends AppCompatActivity {
    Button SignupBloodbank , signupuser,loginbloodbank;
    public static final String UserNameKey="User___";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SignupBloodbank = findViewById(R.id.signup_bloodbank);
        signupuser = findViewById(R.id.signup_user);
        loginbloodbank = findViewById(R.id.loginbloodbank);

        signupuser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomePage.this , RegisterForm.class);
                intent.putExtra(UserNameKey,"commanuser");
                startActivity(intent);
            }
        });

        SignupBloodbank.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomePage.this , RegisterForm.class);
                intent.putExtra(UserNameKey,"BloodBank");
                startActivity(intent);
            }
        });

        loginbloodbank.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomePage.this , LoginForm.class);
                startActivity(intent);
            }
        });
    }
}
