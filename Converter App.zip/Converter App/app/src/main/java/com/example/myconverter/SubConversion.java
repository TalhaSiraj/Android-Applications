package com.example.myconverter;

import android.view.View;
import android.os.Bundle;
import android.widget.Toast;
import android.widget.Button;
import android.content.Intent;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import static android.widget.Toast.LENGTH_LONG;
import androidx.appcompat.app.AppCompatActivity;

public class SubConversion extends AppCompatActivity {
    RadioGroup RG;
    RadioButton MyRadioButton;
    Button MyConvertButton;
    EditText MyUserValue , MyAnswer;
    TextView MySelection;
    float ValueA;
    int state = 0;
    boolean special = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subconversion);
        RG = findViewById(R.id.RG_);
        MyConvertButton = findViewById(R.id.ConvertButton);
        MyUserValue = findViewById(R.id.UserValue);
        MyAnswer = findViewById(R.id.AnswerValue);
        MySelection = findViewById(R.id.SelectionShow);
        int radio_id = RG.getCheckedRadioButtonId();
        MyRadioButton = findViewById(radio_id);
        Intent ReceiveData = getIntent();
        String Category = ReceiveData.getStringExtra(MainActivity.KeyData);
        if(Category.contains("Currency")){
            ((RadioButton) RG .getChildAt(0)).setText("PKR TO EURO");
            ((RadioButton) RG .getChildAt(1)).setText("USD TO PKR");
        }
        else{
            if(Category.contains("Temperature")){
                ((RadioButton) RG .getChildAt(0)).setText("Celsius TO Fahrenheit");
                ((RadioButton) RG .getChildAt(1)).setText("Fahrenheit TO Celsius");
            }else{
                if(Category.contains("Weight")){
                    ((RadioButton) RG .getChildAt(0)).setText("Kilogram TO Gram");
                    ((RadioButton) RG .getChildAt(1)).setText("Gram TO Kilogram");

                }else{
                    if(Category.contains("Length")){
                        ((RadioButton) RG .getChildAt(0)).setText("Meter TO Inches");
                        ((RadioButton) RG .getChildAt(1)).setText("Centimeter TO Meter");
                    }else{
                        if(Category.contains("Frequency")){
                            ((RadioButton) RG .getChildAt(0)).setText("Hertz TO MegaHertz");
                            ((RadioButton) RG .getChildAt(1)).setText("MegaHertz TO Hertz");
                        }else{
                            if(Category.contains("Time")){
                                ((RadioButton) RG .getChildAt(0)).setText("Hour TO Minute");
                                ((RadioButton) RG .getChildAt(1)).setText("Second TO Minute");
                            }else{
                                Toast t = Toast.makeText(SubConversion.this,"Did Not Find Any Value",LENGTH_LONG);
                                t.show();
                            }
                        }
                    }
                }
            }
        }

        MyConvertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(special){
                    if(state == 1){
                        MyAnswer.setText(String.valueOf((Multiply_(Float.parseFloat(MyUserValue.getText().toString()),ValueA))+32.0));
                    }else{
                        if(state == 2){
                            float ValueC = (float) (Float.parseFloat(MyUserValue.getText().toString())-32.0);
                            MyAnswer.setText(String.valueOf(Multiply_(ValueC,ValueA)));
                        }else{
                            Toast t = Toast.makeText(SubConversion.this,"Did Not Find Any Value",LENGTH_LONG);
                            t.show();
                        }
                    }
                }else{
                    if(state == 1){
                        MyAnswer.setText(String.valueOf(Multiply_(Float.parseFloat(MyUserValue.getText().toString()),ValueA)));
                    }else{
                        if(state == 2){
                            MyAnswer.setText(String.valueOf(Divide_(Float.parseFloat(MyUserValue.getText().toString()),ValueA)));
                        }else{
                            Toast t = Toast.makeText(SubConversion.this,"Did Not Find Any Value",LENGTH_LONG);
                            t.show();
                        }
                    }
                }
            }
        });
    }
    public float Multiply_(float ValueB , float ValueA){
        return ValueB*ValueA;
    }
    public float Divide_(float ValueB , float ValueA){
        return ValueB/ValueA;
    }
    public void Check_fun(View v){
        int radio_id = RG.getCheckedRadioButtonId();
        MyRadioButton = findViewById(radio_id);
        if(MyRadioButton.getText().toString().contains("PKR TO EURO")){
            MySelection.setText("PKR TO EURO");
            state = 2;
            ValueA = (float) 195.82;
            special = false;
        }else{
            if(MyRadioButton.getText().toString().contains("USD TO PKR")){
                MySelection.setText("USD TO PKR");
                state = 1;
                ValueA = (float) 160.65;
                special = false;
            }
        }
        if(MyRadioButton.getText().toString().contains("Celsius TO Fahrenheit")){
            MySelection.setText("Celsius TO Fahrenheit");
            state = 1;
            ValueA = (float) 1.8;
            special = true;
        }else{
            if(MyRadioButton.getText().toString().contains("Fahrenheit TO Celsius")){
                MySelection.setText("Fahrenheit TO Celsius");
                state = 2;
                ValueA = (float) 0.555;
                special = true;
            }
        }
        if(MyRadioButton.getText().toString().contains("Kilogram TO Gram")){
            MySelection.setText("Kilogram TO Gram");
            state = 1;
            ValueA = 1000;
            special = false;
        }else{
            if(MyRadioButton.getText().toString().contains("Gram TO Kilogram")){
                MySelection.setText("Gram TO Kilogram");
                state = 2;
                ValueA = 1000;
                special = false;
            }
        }
        if(MyRadioButton.getText().toString().contains("Meter TO Inches")){
            MySelection.setText("Meter TO Inches");
            state = 1;
            ValueA = (float) 39.3701;
            special = false;
        }else{
            if(MyRadioButton.getText().toString().contains("Centimeter TO Meter")){
                MySelection.setText("Centimeter TO Meter");
                state = 2;
                ValueA = 100;
                special = false;
            }
        }
        if(MyRadioButton.getText().toString().contains("Hertz TO MegaHertz")){
            MySelection.setText("Hertz TO MegaHertz");
            state = 2;
            ValueA = (float) 0.000001;
            special = false;
        }else{
            if(MyRadioButton.getText().toString().contains("MegaHertz TO Hertz")){
                MySelection.setText("MegaHertz TO Hertz");
                state = 1;
                ValueA = (float) 0.000001;
                special = false;
            }
        }
        if(MyRadioButton.getText().toString().contains("Hour TO Minute")){
            MySelection.setText("Hour TO Minute");
            state = 1;
            ValueA = 60;
            special = false;
        }else{
            if(MyRadioButton.getText().toString().contains("Second TO Minute")){
                MySelection.setText("Second TO Minute");
                state = 2;
                ValueA = 60;
                special = false;
            }
        }
    }
}