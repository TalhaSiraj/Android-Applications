package com.example.myconverter;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    public static final String KeyData = "Data_";
    Button Currency,Temperature,Weight,Length,Frequency,Time;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Currency = findViewById(R.id.CurrencyButton);
        Temperature = findViewById(R.id.TemperatureButton);
        Weight = findViewById(R.id.WeightButton);
        Length = findViewById(R.id.LengthButton);
        Frequency = findViewById(R.id.FrequencyButton);
        Time =  findViewById(R.id.TimeButton);
        Currency.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent shift = new Intent(MainActivity.this ,SubConversion.class);
                shift.putExtra(KeyData,Currency.getText().toString());
                startActivity(shift);
            }
        });
        Temperature.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent shift = new Intent(MainActivity.this ,SubConversion.class);
                shift.putExtra(KeyData,Temperature.getText().toString());
                startActivity(shift);
            }
        });
        Weight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent shift = new Intent(MainActivity.this ,SubConversion.class);
                shift.putExtra(KeyData,Weight.getText().toString());
                startActivity(shift);
            }
        });
        Length.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent shift = new Intent(MainActivity.this ,SubConversion.class);
                shift.putExtra(KeyData,Length.getText().toString());
                startActivity(shift);
            }
        });
        Frequency.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent shift = new Intent(MainActivity.this ,SubConversion.class);
                shift.putExtra(KeyData,Frequency.getText().toString());
                startActivity(shift);
            }
        });
        Time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent shift = new Intent(MainActivity.this ,SubConversion.class);
                shift.putExtra(KeyData,Time.getText().toString());
                startActivity(shift);
            }
        });
    }
}